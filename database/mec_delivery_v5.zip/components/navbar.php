<div class="col-md-3 text-end">
        <?php if (isset($_SESSION['user_login'])) { ?>
          <a href="/logout" class="btn btn-danger">Logout</a>
        <?php } ?>
      </div>